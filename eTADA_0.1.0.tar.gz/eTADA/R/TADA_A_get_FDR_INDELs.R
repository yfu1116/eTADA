#' @title TADA_A_get_FDR_INDELs
#' @description estimate rr of frameshift indels and calculate final posterior probabilities.
#' @gama initial value of fs rr.
#' @param sample_size the number of individuals.
#' @pp_file_SNV The result of TADA_A_get_FDR_SNVs.R. Posterior Probabilities of all genes after considering all SNV annotations.
#' @import Rcpp
#' @export
#' @examples NULL
#' @useDynLib(eTADA)
#' @importFrom Rcpp sourceCpp

TADA_A_get_FDR_INDELs <- function(gama,sample_size,frameshift_rate_file){

  mg2=fread(frameshift_rate_file)
  N=sample_size

  mydata3 = mg2$prior

  mydata4 = mg2$fs_count

  mydata5 = mg2$fs_rate * 2 * N

  repeat{

    p=(mydata3*dpois(mydata4,gama*mydata5,log=FALSE))/((1-mydata3)*dpois(mydata4,mydata5,log=FALSE)+
                                                         mydata3*dpois(mydata4,gama*mydata5,log=FALSE)) #代入公式

    tes=gama
    gama=sum(p*mydata4)/sum(p*mydata5)
    if(abs(gama-tes)/tes < 1e-8) break

  }

  q0 = 1-p  ### risk probability of non-risk genes

  mg2$post = p
  mg2$q0 = q0

  mg2 = mg2[order(mg2$q0),]

  FDR = c()
  for (i in 1:nrow(mg2)) FDR[i] <- sum(mg2$q0[1:i]) / i
  mg2$FDR = FDR

  list(log_frameshift_rr=log(gama),FDR_ls_0.1 = mg2[mg2$FDR<0.1,], FDR_all=mg2)
}
